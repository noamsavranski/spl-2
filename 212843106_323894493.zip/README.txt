Assignment 2 - SPL
Student 1: Dana Dietrich Hosman - [212843106]
Student 2: [Noam Savranski] - [323894493]


